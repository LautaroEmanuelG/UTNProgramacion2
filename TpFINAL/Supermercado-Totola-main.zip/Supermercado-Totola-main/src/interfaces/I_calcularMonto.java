package interfaces;

public interface I_calcularMonto {
	
	float aCobrar(); // calcula un monto a cobrar

}
