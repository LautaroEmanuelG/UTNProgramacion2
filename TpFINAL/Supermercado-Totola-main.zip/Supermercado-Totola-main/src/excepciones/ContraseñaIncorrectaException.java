package excepciones;

public class Contrase�aIncorrectaException extends Exception{  // contrase�a incorrecta
	public Contrase�aIncorrectaException(String message)
	{
		super(message);
	}
}
