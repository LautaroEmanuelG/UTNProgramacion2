# Supermercado-Totola
Este trabajo final de cuatrimestre fue presentado en conjunto con [Manzo Lautaro](github.com/Lautaro-M) y [Valentini Tobias](github.com/Ttbias2) en 2do año del TUP 
en la Facultad Regional Mar del Plata de la Universidad Tecnológica Nacional ([FRMDPUTN](mdp.utn.edu.ar)). El mismo es una simulación de un supermercado online en
el que el usuario posee la capacidad de agregar productos a un "carrito" virtual y proceder a finalizar una compra. También pueden acceder al programa usuarios como gerentes o empleados, para autogestionar sus datos.
